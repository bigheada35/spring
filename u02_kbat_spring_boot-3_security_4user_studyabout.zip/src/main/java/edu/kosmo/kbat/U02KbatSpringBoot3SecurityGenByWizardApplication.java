package edu.kosmo.kbat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class U02KbatSpringBoot3SecurityGenByWizardApplication {

	public static void main(String[] args) {
		SpringApplication.run(U02KbatSpringBoot3SecurityGenByWizardApplication.class, args);
	}

}
