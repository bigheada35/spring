package edu.kosmo.kbat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class U02KbatSpringBoot3SecurityGenByWizardApplicationTests {

	@Test
	void contextLoads() {
	}

}
