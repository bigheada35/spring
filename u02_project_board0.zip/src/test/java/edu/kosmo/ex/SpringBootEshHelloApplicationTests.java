package edu.kosmo.ex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEshHelloApplicationTests {

	@Test
	void contextLoads() {
	}

}
