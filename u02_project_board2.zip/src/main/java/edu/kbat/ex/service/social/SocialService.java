package edu.kbat.ex.service.social;

public interface SocialService {
	String getAuthorizationUrl();
}
